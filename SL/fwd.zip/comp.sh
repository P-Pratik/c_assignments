echo 'Enter the score'
read x

if [[ $x == 70 ]]; then
  echo 'Good job!'
else 
  echo 'bad score'
fi
