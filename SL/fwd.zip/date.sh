today=$(date)

echo “Today is $today”
