ARG=($*)

echo ${ARG[0]}
echo ${ARG[1]}
echo ${ARG[2]}
echo ${ARG[3]}
echo ${ARG[4]}
